Eric Olsson
Git Practica Ejercicio 1
27 de noviembre

**Respuestas a las preguntas**

1° Pregunta: ¿Qué comando utilizaste en el paso 11? ¿Por qué?

1° Respuesta: Yo usé el comando $ git reset HEAD~1 porque necesitaba perder los cambios realizados en el working 
copy, pero mantenerlos en el working copy. El comando $ git reset --hard HEAD~1 se deshacer el último commit pero NO 
mantener lo que había en mi working copy. 


2° Pregunta: ¿Qué comando o comandos utilizaste en el paso 12? ¿Por qué?

2° Respuesta: Yo usé los comandos:
	$ git add git-nuestro.md
	$ git commit -m "Archivo git-nuestro.md v2.1 recommitted"
porque necesitaba repasar los cambios que estaban en el working copy. El comando $ git restore tendría "discard 
changes in working directory" y no querida eso.∑


3° Pregunta: El merge del paso 13, ¿Causó algún conflicto? ¿Por qué?

3° Respuesta: ≈El merge no creó un conflicto porque los cambios del paso 9 se aplicaron al master en el 
paso 10 y luego nuevamente en el paso 12. 


4° Pregunta: El merge del paso 19, ¿Causó algún conflicto? ¿Por qué?

4° Respuesta: Si, el merge creó un conflicto porque los cambios en styled (estilo bold) eran diferente de los cambios 
en htmlify (estilo de html). 


5° Pregunta: El merge del paso 21, ¿Causó algún conflicto? ¿Por qué?

5° Respuesta: No era un conflicto porque arreglé los conflictos en styled antes del merge. 


6° Pregunta: ¿Qué comando o comandos utilizaste en el paso 25?

6° Respuesta: Utilicé git log --graph


7° Pregunta: El merge del paso 26, ¿Podría ser fast forward? ¿Por qué?

7° Respuesta: Si, podría hacer fast forward porque la rama title era la más nueva y el cambio era una liña que no 
conflictaría con lo demas del contento.


8° Pregunta: ¿Qué comando o comandos utilizaste en el paso 27?

8° Respuesta: $ git reset --hard 68c363f // commit before the merge: title added


9° Pregunta: ¿Qué comando o comandos utilizaste en el paso 28?

9° Respuesta: Hice el comando $ git status y no era cambios presente. No se porque. Hice:

$ git status
On branch title
Untracked files:
  (use "git add <file>..." to include in what will be committed)
	.DS_Store
	readme-preguntas-respuestas.md

nothing added to commit but untracked files present (use "git add" to track)

M1-MBP-EJO:practicaEjercicio1EO ericolsson$ git status
On branch main
Untracked files:
  (use "git add <file>..." to include in what will be committed)
	.DS_Store
	readme-preguntas-respuestas.md

nothing added to commit but untracked files present (use "git add" to track)

Pero, si era, utilicía el comando 
1. $ rm <filename> // remove some untracked files
2. $ git reset --hard HEAD //remove the changes from the staging area
3. $ git stash // remove an untracked file


10° Pregunta: ¿Qué comando o comandos utilizaste en el paso 29?

10° Respuesta: Hice el comando: 
$ git checkout main // move off target deletion
$ git branch --delete title


11° Pregunta: ¿Qué comando o comandos utilizaste en el paso 30?

11° Respuesta: Hice los comandos:
$ git reflog // notar <commit numero>
$ git status
$ git reset --soft 75df537


12° Pregunta: ¿Qué comando o comandos usaste en el paso 32?

12° Respuesta: Hice los comandos:
$ git reflog // busca el primer commit
$ git checkout b633725


13° Pregunta: ¿Qué comando o comandos usaste en el punto 33?

13° Respuesta: Hice los comandos:
$ git reflog // busca el ultimo commit
$ git checkout 68c363f


